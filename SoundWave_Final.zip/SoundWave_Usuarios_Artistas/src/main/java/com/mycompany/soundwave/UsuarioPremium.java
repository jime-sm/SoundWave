package com.mycompany.soundwave;

public class UsuarioPremium extends Usuario {
    public UsuarioPremium(String nombreUsuario, String correo, String contrasena) {
        super(nombreUsuario, correo, contrasena);
    }

    @Override
    public String obtenerTipoPlan() { return "Premium"; }

    @Override
    public void mostrarPerfil() {
        super.mostrarPerfil();
        System.out.println("Puedes escuchar música sin anuncios.");
    }
}
