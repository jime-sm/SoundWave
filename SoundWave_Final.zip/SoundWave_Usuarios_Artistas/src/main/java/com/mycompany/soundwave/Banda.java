package com.mycompany.soundwave;

public class Banda extends Artista {
    private int integrantes;

    public Banda(String nombre, String generoMusical, int oyentesMensuales, int integrantes) {
        super(nombre, generoMusical, oyentesMensuales);
        this.integrantes = integrantes;
    }

    public int getIntegrantes() { return integrantes; }

    @Override
    public void mostrarInfoArtista() {
        super.mostrarInfoArtista();
        System.out.println("  Banda | Integrantes: " + integrantes);
    }
}
