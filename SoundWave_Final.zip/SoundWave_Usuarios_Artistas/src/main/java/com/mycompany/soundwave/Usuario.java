package com.mycompany.soundwave;

// Clase padre: contiene lo que tienen en común todos los usuarios.
public class Usuario {
    private String nombreUsuario;
    private String correo;
    private String contrasena;

    public Usuario(String nombreUsuario, String correo, String contrasena) {
        this.nombreUsuario = nombreUsuario;
        this.correo = correo;
        this.contrasena = contrasena;
    }

    public String getNombreUsuario() { return nombreUsuario; }
    public void setNombreUsuario(String nombreUsuario) { this.nombreUsuario = nombreUsuario; }
    public String getCorreo() { return correo; }
    public void setCorreo(String correo) {
        if (correo != null && correo.contains("@")) this.correo = correo;
    }
    public String getContrasena() { return contrasena; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }

    public boolean iniciarSesion(String correoIngresado, String contrasenaIngresada) {
        return correo.equals(correoIngresado) && contrasena.equals(contrasenaIngresada);
    }

    public String obtenerTipoPlan() { return "Usuario"; }
    public void mostrarPerfil() {
        System.out.println("Usuario: " + nombreUsuario + " | Correo: " + correo
                + " | Plan: " + obtenerTipoPlan());
    }
}
