package com.mycompany.soundwave;

public class ArtistaSolista extends Artista {
    private String pais;

    public ArtistaSolista(String nombre, String generoMusical, int oyentesMensuales, String pais) {
        super(nombre, generoMusical, oyentesMensuales);
        this.pais = pais;
    }

    public String getPais() { return pais; }

    @Override
    public void mostrarInfoArtista() {
        super.mostrarInfoArtista();
        System.out.println("  Solista | País: " + pais);
    }
}
