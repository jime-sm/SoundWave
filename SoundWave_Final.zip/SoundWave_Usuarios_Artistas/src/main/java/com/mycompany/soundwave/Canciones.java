package com.mycompany.soundwave;

public class Canciones extends Contenido {
    private String artista;

    public Canciones(String nombre, String artista, double duracion, int reproducciones) {
        super(nombre, duracion, reproducciones);
        this.artista = artista;
    }
    public String getArtista() { return artista; }
    public void setArtista(String artista) { this.artista = artista; }

    @Override
    public String mostrarEnMenu() {
        return "Canción: " + getNombre() + " - " + artista;
    }
    @Override
    public void reproducir() { reproducirCancion(); }

    public void reproducirCancion() {
        sumarReproduccion();
        System.out.println("Reproduciendo canción: " + getNombre() + " - " + artista
                + " (Total reproducciones: " + getReproducciones() + ")");
    }
}
