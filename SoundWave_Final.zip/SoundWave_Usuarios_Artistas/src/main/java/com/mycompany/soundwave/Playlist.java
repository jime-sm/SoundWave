package com.mycompany.soundwave;

import java.util.ArrayList;

public class Playlist {
    private String nombrePlaylist;
    private boolean esPublica;
    private ArrayList<Contenido> contenidos;

    public Playlist(String nombrePlaylist, boolean esPublica) {
        this.nombrePlaylist = nombrePlaylist;
        this.esPublica = esPublica;
        this.contenidos = new ArrayList<Contenido>();
    }
    public String getNombrePlaylist() { return nombrePlaylist; }
    public void agregarContenido(Contenido contenido) { contenidos.add(contenido); }
    public void mostrarInfoPlaylist() {
        String tipo = esPublica ? "Pública" : "Privada";
        System.out.println("Playlist: " + nombrePlaylist + " | Contenidos: "
                + contenidos.size() + " | Visibilidad: " + tipo);
        for (Contenido contenido : contenidos) {
            System.out.println("  - " + contenido.mostrarEnMenu());
        }
    }
}
