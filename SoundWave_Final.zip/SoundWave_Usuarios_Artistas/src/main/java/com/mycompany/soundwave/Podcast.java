package com.mycompany.soundwave;

public class Podcast extends Contenido {
    private String presentador;

    public Podcast(String nombre, String presentador, double duracion, int reproducciones) {
        super(nombre, duracion, reproducciones);
        this.presentador = presentador;
    }
    public String getPresentador() { return presentador; }

    @Override
    public String mostrarEnMenu() {
        return "Podcast: " + getNombre() + " - " + presentador;
    }
    @Override
    public void reproducir() {
        sumarReproduccion();
        System.out.println("Escuchando podcast: " + getNombre() + " con " + presentador
                + " (Total reproducciones: " + getReproducciones() + ")");
    }
}
