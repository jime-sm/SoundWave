package com.mycompany.soundwave;

import java.util.ArrayList;
import java.util.Scanner;

public class SoundWave {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        // Varios usuarios guardados en una lista, como las canciones y los álbumes.
        ArrayList<Usuario> usuarios = new ArrayList<Usuario>();
        usuarios.add(new UsuarioPremium("Maria_Jimena", "maria@unilibre.edu.co", "12345"));
        usuarios.add(new UsuarioGratuito("Karen", "karen@unilibre.edu.co", "12345"));
        usuarios.add(new UsuarioPremium("Valentina", "valentina@correo.com", "12345"));
        Usuario usuarioActivo = null;

        while (usuarioActivo == null) {
            System.out.println("\n===== BIENVENIDO A SOUNDWAVE =====");
            System.out.println("1. Registrarse");
            System.out.println("2. Iniciar sesión");
            System.out.println("3. Ver usuarios y sus planes");
            System.out.println("0. Salir");
            System.out.print("Elige una opción: ");
            int opcion = entrada.nextInt();

            if (opcion == 1) {
                System.out.print("Nombre de usuario (sin espacios): ");
                String nombre = entrada.next();
                System.out.print("Correo: ");
                String correo = entrada.next();
                boolean existe = false;
                for (Usuario usuario : usuarios) {
                    if (usuario.getCorreo().equals(correo)) existe = true;
                }
                if (existe) {
                    System.out.println("Ese correo ya está registrado.");
                    continue;
                }
                System.out.print("Contraseña: ");
                String contrasena = entrada.next();
                System.out.println("Elige tu plan: 1. Gratuito  2. Premium");
                int plan = entrada.nextInt();
                if (plan == 1) {
                    usuarioActivo = new UsuarioGratuito(nombre, correo, contrasena);
                } else if (plan == 2) {
                    usuarioActivo = new UsuarioPremium(nombre, correo, contrasena);
                } else {
                    System.out.println("Plan no válido.");
                    continue;
                }
                usuarios.add(usuarioActivo);
                System.out.println("Usuario registrado correctamente.");
            } else if (opcion == 2) {
                System.out.print("Correo: ");
                String correo = entrada.next();
                System.out.print("Contraseña: ");
                String contrasena = entrada.next();
                for (Usuario usuario : usuarios) {
                    if (usuario.iniciarSesion(correo, contrasena)) {
                        usuarioActivo = usuario;
                        break;
                    }
                }
                if (usuarioActivo == null) System.out.println("Correo o contraseña incorrectos.");
            } else if (opcion == 3) {
                mostrarUsuarios(usuarios);
            } else if (opcion == 0) {
                return;
            } else {
                System.out.println("Opción no válida.");
            }
        }
        System.out.println("\n--- TU PERFIL ---");
        usuarioActivo.mostrarPerfil();
        mostrarUsuarios(usuarios);

        ArrayList<Artista> artistas = new ArrayList<Artista>();
        artistas.add(new Artista("Bad Bunny", "Urbano", 52000000));
        artistas.add(new ArtistaSolista("Shakira", "Pop Latino", 68000000, "Colombia"));
        artistas.add(new Artista("Arctic Monkeys", "Indie Rock", 55000000));
        artistas.add(new Artista("Peso Pluma, Kenia OS", "Regional Mexicano / Pop", 42000000));
        artistas.add(new Artista("Kylie Cantrall", "Pop", 3500000));
        artistas.add(new Artista("Sabrina Carpenter", "Pop", 82000000));
        artistas.add(new Artista("Rauw Alejandro, Chencho Corleone", "Urbano / Reguetón", 48000000));
        artistas.add(new Banda("Queen", "Rock", 55000000, 4));
        artistas.add(new Artista("Nirvana", "Grunge / Rock", 32000000));
        artistas.add(new Artista("Linkin Park", "Rock Alternativo", 45000000));
        artistas.add(new Artista("Guns N' Roses", "Hard Rock", 30000000));
        artistas.add(new Artista("AC/DC", "Hard Rock", 37000000));
        artistas.add(new Artista("Avicii", "Música Electrónica", 34000000));
        artistas.add(new Artista("The Weeknd", "R&B / Pop", 110000000));
        artistas.add(new Artista("Ed Sheeran", "Pop", 85000000));
        artistas.add(new Artista("Billie Eilish", "Pop Alternativo", 75000000));
        artistas.add(new Artista("Olivia Rodrigo", "Pop", 50000000));
        artistas.add(new Artista("ROSÉ, Bruno Mars", "Pop", 100000000));
        artistas.add(new Banda("BLACKPINK", "K-Pop", 18000000, 4));
        artistas.add(new Artista("IVE", "K-Pop", 10000000));
        artistas.add(new Artista("Arctic Monkeys", "Indie Rock", 55000000));
        artistas.add(new Artista("Conan Gray", "Pop", 20000000));
        artistas.add(new Artista("Enanitos Verdes", "Rock en Español", 12000000));
        artistas.add(new Artista("Marc Anthony", "Salsa", 18000000));
        artistas.add(new Artista("Celia Cruz", "Salsa", 8000000));
        artistas.add(new Artista("Claude Debussy", "Música Clásica", 5000000));
        artistas.add(new Artista("Antonio Vivaldi", "Música Clásica", 7000000));
        artistas.add(new Artista("Eminem", "Hip-Hop / Rap", 80000000));
        artistas.add(new Artista("Lil Nas X, Jack Harlow", "Hip-Hop / Rap", 40000000));
        artistas.add(new Artista("deadmau5", "Música Electrónica", 5000000));

        ArrayList<Album> albumes = new ArrayList<Album>();
        albumes.add(new Album("Un Verano Sin Ti", 2022, 23));
        albumes.add(new Album("Pies Descalzos", 1995, 11));
        albumes.add(new Album("AM", 2013, 12));
        albumes.add(new Album("ÉXODO", 2024, 24));
        albumes.add(new Album("Descendants: The Rise of Red", 2024, 13));
        albumes.add(new Album("Short n' Sweet", 2024, 12));
        albumes.add(new Album("Vice Versa", 2021, 14));
        albumes.add(new Album("A Night at the Opera", 1975, 12));
        albumes.add(new Album("Nevermind", 1991, 13));
        albumes.add(new Album("Meteora", 2003, 13));
        albumes.add(new Album("Appetite for Destruction", 1987, 12));
        albumes.add(new Album("Back in Black", 1980, 10));
        albumes.add(new Album("True", 2013, 10));
        albumes.add(new Album("After Hours", 2020, 14));
        albumes.add(new Album("Divide", 2017, 16));
        albumes.add(new Album("Happier Than Ever", 2021, 16));
        albumes.add(new Album("SOUR", 2021, 11));
        albumes.add(new Album("rosie", 2024, 12));
        albumes.add(new Album("The Album", 2020, 8));
        albumes.add(new Album("I've IVE", 2023, 11));
        albumes.add(new Album("Favourite Worst Nightmare", 2007, 12));
        albumes.add(new Album("Kid Krow", 2020, 12));
        albumes.add(new Album("Big Bang", 1994, 13));
        albumes.add(new Album("3.0", 2013, 10));
        albumes.add(new Album("Mi Vida Es Cantar", 1998, 11));
        albumes.add(new Album("Suite Bergamasque", 1905, 4));
        albumes.add(new Album("The Four Seasons", 1959, 12));
        albumes.add(new Album("8 Mile", 2002, 16));
        albumes.add(new Album("Montero", 2021, 15));
        albumes.add(new Album("For Lack of a Better Name", 2009, 10));

        ArrayList<Canciones> canciones = new ArrayList<Canciones>();
        canciones.add(new Canciones("Titi Me Pregunto", "Bad Bunny", 4.03, 1450));
        canciones.add(new Canciones("Estoy Aqui", "Shakira", 3.52, 920));
        canciones.add(new Canciones("Do i wanna know?", "Artic Monkeys", 4.32, 15000));
        canciones.add(new Canciones("Tommy & Pamela", "Peso Pluma, Kenia Os", 3.29, 1000));
        canciones.add(new Canciones("Space Between", "Kylie Cantrall", 3.39, 810));
        canciones.add(new Canciones("Expresso", "Sabrina Carpenter", 2.25, 20000));
        canciones.add(new Canciones("El Efecto", "Rauw Alejandro, Chencho Carleone", 3.37, 16000));
        canciones.add(new Canciones("Bohemian Rhapsody", "Queen", 5.55, 18500));
        canciones.add(new Canciones("Smells Like Teen Spirit", "Nirvana", 5.01, 16000));
        canciones.add(new Canciones("Numb", "Linkin Park", 3.05, 22000));
        canciones.add(new Canciones("Sweet Child O' Mine", "Guns N' Roses", 5.56, 19000));
        canciones.add(new Canciones("Back In Black", "AC/DC", 4.15, 14000));
        canciones.add(new Canciones("Wake Me Up", "Avicii", 4.09, 17500));
        canciones.add(new Canciones("Blinding Lights", "The Weeknd", 3.20, 25000));
        canciones.add(new Canciones("Shape of You", "Ed Sheeran", 3.53, 28000));
        canciones.add(new Canciones("Happier Than Ever", "Billie Eilish", 4.58, 13000));
        canciones.add(new Canciones("Good 4 U", "Olivia Rodrigo", 2.58, 21000));
        canciones.add(new Canciones("APT.", "ROSÉ, Bruno Mars", 2.49, 23000));
        canciones.add(new Canciones("How You Like That", "BLACKPINK", 3.01, 20000));
        canciones.add(new Canciones("I AM", "IVE", 3.03, 12500));
        canciones.add(new Canciones("505", "Arctic Monkeys", 4.13, 18000));
        canciones.add(new Canciones("Heather", "Conan Gray", 3.18, 11500));
        canciones.add(new Canciones("Lamento Boliviano", "Enanitos Verdes", 3.48, 9500));
        canciones.add(new Canciones("Vivir Mi Vida", "Marc Anthony", 4.13, 15000));
        canciones.add(new Canciones("La Vida Es un Carnaval", "Celia Cruz", 4.16, 11000));
        canciones.add(new Canciones("Clair de Lune", "Claude Debussy", 5.00, 7000));
        canciones.add(new Canciones("The Four Seasons: Spring", "Antonio Vivaldi", 3.30, 6000));
        canciones.add(new Canciones("Lose Yourself", "Eminem", 5.26, 17000));
        canciones.add(new Canciones("Industry Baby", "Lil Nas X, Jack Harlow", 3.32, 15500));
        canciones.add(new Canciones("Strobe", "Deadmau5", 10.37, 8500));

        System.out.println("\n--- ARTISTAS (los datos de solistas y bandas aparecen debajo) ---");
        for (Artista artista : artistas) {
            artista.mostrarInfoArtista();
        }
        System.out.println("\n--- ÁLBUMES ---");
        for (Album album : albumes) {
            album.mostrarDetallesAlbum();
        }
        System.out.println("\n--- CANCIONES Y PODCASTS ---");
        // La clase padre Contenido permite guardar canciones y podcasts juntos.
        ArrayList<Contenido> catalogo = new ArrayList<Contenido>();
        for (Canciones cancion : canciones) {
            catalogo.add(cancion);
        }
        catalogo.add(new Podcast("Historias detrás de la música", "Jimena", 25.0, 0));
        catalogo.add(new Podcast("Charlas de artistas", "Karen", 18.0, 0));

        Playlist playlist = new Playlist("Mis favoritos", true);
        playlist.agregarContenido(canciones.get(0));
        playlist.agregarContenido(catalogo.get(30));
        playlist.mostrarInfoPlaylist();

        Reproductor reproductor = new Reproductor("En Pausa", 40);
        int seleccion = -1;
        while (seleccion != 0) {
            System.out.println("\nElige un contenido (0 salir, -1 ver tu perfil, -2 ver usuarios):");
            for (int i = 0; i < catalogo.size(); i++) {
                System.out.println((i + 1) + ". " + catalogo.get(i).mostrarEnMenu());
            }
            seleccion = entrada.nextInt();
            if (seleccion == -1) {
                usuarioActivo.mostrarPerfil();
            } else if (seleccion == -2) {
                mostrarUsuarios(usuarios);
            } else if (seleccion > 0 && seleccion <= catalogo.size()) {
                reproductor.cambiarEstado("Reproduciendo");
                // Polimorfismo: reproducir() cambia según sea Canciones o Podcast.
                catalogo.get(seleccion - 1).reproducir();
            } else if (seleccion != 0) {
                System.out.println("Número no válido.");
            }
        }
        reproductor.cambiarEstado("En Pausa");
        reproductor.ajustarVolumen(75);
        entrada.close();
    }

    public static void mostrarUsuarios(ArrayList<Usuario> usuarios) {
        System.out.println("\n--- USUARIOS REGISTRADOS ---");
        for (Usuario usuario : usuarios) {
            // La clase concreta decide si muestra Gratuito o Premium.
            System.out.println(usuario.getNombreUsuario() + " | " + usuario.getCorreo()
                    + " | Plan: " + usuario.obtenerTipoPlan());
        }
    }
}
