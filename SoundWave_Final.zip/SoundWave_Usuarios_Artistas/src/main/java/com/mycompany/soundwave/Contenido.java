package com.mycompany.soundwave;

// Clase padre de los contenidos que se pueden reproducir.
public abstract class Contenido {
    private String nombre;
    private double duracion;
    private int reproducciones;

    public Contenido(String nombre, double duracion, int reproducciones) {
        this.nombre = nombre;
        this.duracion = duracion;
        this.reproducciones = reproducciones;
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public double getDuracion() { return duracion; }
    public void setDuracion(double duracion) {
        if (duracion > 0) this.duracion = duracion;
    }
    public int getReproducciones() { return reproducciones; }
    public void setReproducciones(int reproducciones) {
        if (reproducciones >= 0) this.reproducciones = reproducciones;
    }
    public void sumarReproduccion() { reproducciones++; }
    public abstract void reproducir();
    public abstract String mostrarEnMenu();
}
