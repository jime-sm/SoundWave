package com.mycompany.soundwave;

public class UsuarioGratuito extends Usuario {
    public UsuarioGratuito(String nombreUsuario, String correo, String contrasena) {
        super(nombreUsuario, correo, contrasena);
    }

    @Override
    public String obtenerTipoPlan() { return "Gratuito"; }

    @Override
    public void mostrarPerfil() {
        super.mostrarPerfil();
        System.out.println("Puedes escuchar música con anuncios.");
    }
}
